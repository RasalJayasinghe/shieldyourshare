
export interface PIIDetection {
  type: 'email' | 'phone' | 'ssn' | 'credit_card' | 'name' | 'address' | 'license_plate';
  confidence: number;
  location: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  text: string;
}

export interface FileData {
  id: string;
  name: string;
  type: 'image' | 'video';
  url: string;
  size: number;
  detections: PIIDetection[];
  riskScore: number;
  status: 'scanning' | 'complete' | 'error';
}
