import { pipeline } from '@huggingface/transformers';
import { createWorker } from 'tesseract.js';
import { PIIDetection } from '@/types/file';

// Initialize AI models
let objectDetector: any = null;
let ocrWorker: any = null;

export const initializeAI = async () => {
  try {
    // Initialize YOLO object detection model
    objectDetector = await pipeline(
      'object-detection',
      'Xenova/yolov9-c',
      { device: 'webgpu' }
    );

    // Initialize Tesseract OCR
    ocrWorker = await createWorker();
    await ocrWorker.loadLanguage('eng');
    await ocrWorker.initialize('eng');

    console.log('AI models initialized successfully');
  } catch (error) {
    console.warn('Failed to initialize WebGPU, falling back to CPU:', error);
    try {
      // Fallback to CPU if WebGPU fails
      objectDetector = await pipeline(
        'object-detection',
        'Xenova/yolov9-c'
      );
    } catch (cpuError) {
      console.error('Failed to initialize AI models:', cpuError);
    }
  }
};

const isPotentialPII = (text: string): { type: PIIDetection['type']; confidence: number } | null => {
  const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
  const phoneRegex = /(\+?1[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}/g;
  const ssnRegex = /\b\d{3}-?\d{2}-?\d{4}\b/g;
  const creditCardRegex = /\b(?:\d{4}[-\s]?){3}\d{4}\b/g;
  const nameRegex = /\b[A-Z][a-z]+ [A-Z][a-z]+\b/g;
  
  if (emailRegex.test(text)) {
    return { type: 'email', confidence: 0.9 };
  }
  if (phoneRegex.test(text)) {
    return { type: 'phone', confidence: 0.85 };
  }
  if (ssnRegex.test(text)) {
    return { type: 'ssn', confidence: 0.95 };
  }
  if (creditCardRegex.test(text)) {
    return { type: 'credit_card', confidence: 0.9 };
  }
  if (nameRegex.test(text)) {
    return { type: 'name', confidence: 0.7 };
  }
  
  return null;
};

export const detectPII = async (file: File): Promise<PIIDetection[]> => {
  const detections: PIIDetection[] = [];
  
  try {
    // Only process images for now
    if (!file.type.startsWith('image/')) {
      return detections;
    }

    const imageUrl = URL.createObjectURL(file);
    const img = new Image();
    
    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = reject;
      img.src = imageUrl;
    });

    // Run OCR to extract text
    if (ocrWorker) {
      const { data } = await ocrWorker.recognize(img);
      
      // Process each word for PII
      data.words.forEach((word: any) => {
        if (word.confidence > 0.6 && word.text.trim()) {
          const piiMatch = isPotentialPII(word.text);
          if (piiMatch) {
            detections.push({
              type: piiMatch.type,
              confidence: piiMatch.confidence * (word.confidence / 100),
              location: {
                x: word.bbox.x0,
                y: word.bbox.y0,
                width: word.bbox.x1 - word.bbox.x0,
                height: word.bbox.y1 - word.bbox.y0
              },
              text: word.text
            });
          }
        }
      });
    }

    // Run object detection for visual PII (faces, license plates, etc.)
    if (objectDetector) {
      const objects = await objectDetector(img);
      
      objects.forEach((obj: any) => {
        // Map YOLO object types to PII types
        if (obj.label.includes('person') && obj.score > 0.5) {
          detections.push({
            type: 'name', // Faces could indicate person identification
            confidence: obj.score,
            location: {
              x: obj.box.xmin,
              y: obj.box.ymin,
              width: obj.box.xmax - obj.box.xmin,
              height: obj.box.ymax - obj.box.ymin
            },
            text: 'Detected person/face'
          });
        }
        
        if (obj.label.includes('car') && obj.score > 0.5) {
          // Cars might have license plates
          detections.push({
            type: 'license_plate',
            confidence: obj.score * 0.7, // Lower confidence as it's indirect
            location: {
              x: obj.box.xmin,
              y: obj.box.ymin,
              width: obj.box.xmax - obj.box.xmin,
              height: obj.box.ymax - obj.box.ymin
            },
            text: 'Potential license plate area'
          });
        }
      });
    }

    URL.revokeObjectURL(imageUrl);
    
  } catch (error) {
    console.error('Error during PII detection:', error);
  }
  
  return detections;
};

export const cleanup = async () => {
  if (ocrWorker) {
    await ocrWorker.terminate();
  }
};