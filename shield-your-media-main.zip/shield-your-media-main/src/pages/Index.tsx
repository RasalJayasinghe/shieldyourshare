
import React, { useState } from 'react';
import { FileUpload } from '@/components/FileUpload';
import { PIIResults } from '@/components/PIIResults';
import { Header } from '@/components/Header';
import { FileData } from '@/types/file';

const Index = () => {
  const [uploadedFiles, setUploadedFiles] = useState<FileData[]>([]);

  const handleFileUpload = (files: FileData[]) => {
    setUploadedFiles(prev => [...prev, ...files]);
  };

  const handleDeleteFile = (fileId: string) => {
    setUploadedFiles(prev => prev.filter(file => file.id !== fileId));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="text-center space-y-4">
            <h1 className="text-4xl font-bold text-slate-800">
              PII Scanner & Protection Tool
            </h1>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              Upload your images and videos to scan for exposed Personally Identifiable Information. 
              Get instant risk assessments and recommendations to keep your content secure.
            </p>
          </div>

          <FileUpload onFileUpload={handleFileUpload} />

          {uploadedFiles.length > 0 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-semibold text-slate-800">
                Scan Results ({uploadedFiles.length} files)
              </h2>
              <div className="grid gap-6">
                {uploadedFiles.map((file) => (
                  <PIIResults 
                    key={file.id} 
                    file={file} 
                    onDelete={handleDeleteFile}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Index;
