import React, { useState } from 'react';
import { AlertTriangle, Trash2, Shield, Eye, Lightbulb, Video } from 'lucide-react';
import { FileData } from '@/types/file';
import { RecommendationsPanel } from './RecommendationsPanel';

interface PIIResultsProps {
  file: FileData;
  onDelete: (fileId: string) => void;
}

export const PIIResults: React.FC<PIIResultsProps> = ({ file, onDelete }) => {
  const [showRecommendations, setShowRecommendations] = useState(false);
  const [showDetections, setShowDetections] = useState(true);

  const getRiskColor = (score: number) => {
    if (score >= 8) return 'text-red-600 bg-red-100';
    if (score >= 5) return 'text-orange-600 bg-orange-100';
    if (score >= 2) return 'text-yellow-600 bg-yellow-100';
    return 'text-green-600 bg-green-100';
  };

  const getRiskLabel = (score: number) => {
    if (score >= 8) return 'High Risk';
    if (score >= 5) return 'Medium Risk';
    if (score >= 2) return 'Low Risk';
    return 'Secure';
  };

  const handleAutoDelete = () => {
    if (window.confirm(`Are you sure you want to delete "${file.name}"? This action cannot be undone.`)) {
      onDelete(file.id);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-slate-800 mb-1">{file.name}</h3>
            <p className="text-sm text-slate-500">
              {file.type.toUpperCase()} • {(file.size / 1024 / 1024).toFixed(2)} MB
            </p>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className={`px-3 py-1 rounded-full text-sm font-medium ${getRiskColor(file.riskScore)}`}>
              {getRiskLabel(file.riskScore)} ({file.riskScore}/10)
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="relative">
            {file.type === 'image' ? (
              <div className="relative">
                <img 
                  src={file.url} 
                  alt={file.name}
                  className="w-full h-64 object-cover rounded-lg border"
                />
                {showDetections && file.detections.map((detection, index) => (
                  <div
                    key={index}
                    className="absolute border-2 border-red-500 bg-red-500 bg-opacity-20 rounded"
                    style={{
                      left: `${(detection.location.x / 500) * 100}%`,
                      top: `${(detection.location.y / 300) * 100}%`,
                      width: `${(detection.location.width / 500) * 100}%`,
                      height: `${(detection.location.height / 300) * 100}%`,
                    }}
                  >
                    <div className="absolute -top-6 left-0 bg-red-500 text-white text-xs px-2 py-1 rounded">
                      {detection.type}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="w-full h-64 bg-slate-100 rounded-lg border flex items-center justify-center">
                <div className="text-center">
                  <Video className="h-12 w-12 text-slate-400 mx-auto mb-2" />
                  <p className="text-slate-600">Video Preview</p>
                  <p className="text-sm text-slate-500">{file.name}</p>
                </div>
              </div>
            )}
            
            <button
              onClick={() => setShowDetections(!showDetections)}
              className="absolute top-2 right-2 bg-white bg-opacity-90 hover:bg-opacity-100 p-2 rounded-lg shadow-sm transition-all duration-200"
            >
              <Eye className={`h-4 w-4 ${showDetections ? 'text-blue-600' : 'text-slate-400'}`} />
            </button>
          </div>

          <div className="space-y-4">
            <div>
              <h4 className="font-semibold text-slate-800 mb-3 flex items-center">
                <AlertTriangle className="h-5 w-5 text-orange-500 mr-2" />
                Detected PII ({file.detections.length})
              </h4>
              
              {file.detections.length === 0 ? (
                <div className="flex items-center text-green-600 bg-green-50 p-3 rounded-lg">
                  <Shield className="h-5 w-5 mr-2" />
                  No PII detected - Your content is secure!
                </div>
              ) : (
                <div className="space-y-2">
                  {file.detections.map((detection, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-red-50 border border-red-200 rounded-lg">
                      <div>
                        <span className="font-medium text-red-800 capitalize">
                          {detection.type.replace('_', ' ')}
                        </span>
                        <p className="text-sm text-red-600">{detection.text}</p>
                      </div>
                      <span className="text-sm font-medium text-red-700">
                        {Math.round(detection.confidence * 100)}%
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setShowRecommendations(!showRecommendations)}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors duration-200 flex items-center justify-center"
              >
                <Lightbulb className="h-4 w-4 mr-2" />
                Recommendations
              </button>
              
              <button
                onClick={handleAutoDelete}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg font-medium transition-colors duration-200 flex items-center justify-center"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Auto Delete
              </button>
            </div>
          </div>
        </div>

        {showRecommendations && (
          <div className="mt-6 pt-6 border-t border-slate-200">
            <RecommendationsPanel file={file} />
          </div>
        )}
      </div>
    </div>
  );
};
