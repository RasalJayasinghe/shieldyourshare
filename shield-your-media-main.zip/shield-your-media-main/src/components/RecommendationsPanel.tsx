
import React from 'react';
import { CheckCircle, AlertCircle, Info } from 'lucide-react';
import { FileData } from '@/types/file';

interface RecommendationsPanelProps {
  file: FileData;
}

export const RecommendationsPanel: React.FC<RecommendationsPanelProps> = ({ file }) => {
  const getRecommendations = () => {
    const recommendations = [];
    
    if (file.detections.length === 0) {
      return [
        {
          type: 'success',
          title: 'Content is Secure',
          description: 'No PII detected in this file. It\'s safe to share publicly.',
          icon: CheckCircle,
          color: 'text-green-600 bg-green-50 border-green-200'
        }
      ];
    }

    file.detections.forEach(detection => {
      switch (detection.type) {
        case 'email':
          recommendations.push({
            type: 'warning',
            title: 'Email Address Detected',
            description: 'Consider blurring or cropping the email address. Use image editing software to redact this information before sharing.',
            icon: AlertCircle,
            color: 'text-orange-600 bg-orange-50 border-orange-200'
          });
          break;
        case 'phone':
          recommendations.push({
            type: 'warning',
            title: 'Phone Number Detected',
            description: 'Phone numbers can be used for identity theft. Blur or remove the phone number from the image.',
            icon: AlertCircle,
            color: 'text-red-600 bg-red-50 border-red-200'
          });
          break;
        case 'name':
          recommendations.push({
            type: 'info',
            title: 'Name Detected',
            description: 'Personal names can compromise privacy. Consider if this information needs to be visible.',
            icon: Info,
            color: 'text-blue-600 bg-blue-50 border-blue-200'
          });
          break;
        case 'address':
          recommendations.push({
            type: 'warning',
            title: 'Address Information Detected',
            description: 'Physical addresses pose a high security risk. This should be removed or obscured before sharing.',
            icon: AlertCircle,
            color: 'text-red-600 bg-red-50 border-red-200'
          });
          break;
        case 'ssn':
          recommendations.push({
            type: 'critical',
            title: 'Social Security Number Detected',
            description: 'CRITICAL: SSNs enable identity theft. This content should NOT be shared and the information must be completely removed.',
            icon: AlertCircle,
            color: 'text-red-800 bg-red-100 border-red-300'
          });
          break;
        case 'credit_card':
          recommendations.push({
            type: 'critical',
            title: 'Credit Card Information Detected',
            description: 'CRITICAL: Credit card numbers enable financial fraud. Remove this content immediately.',
            icon: AlertCircle,
            color: 'text-red-800 bg-red-100 border-red-300'
          });
          break;
      }
    });

    // Add general recommendations
    if (file.riskScore >= 5) {
      recommendations.push({
        type: 'info',
        title: 'General Security Tips',
        description: 'Use photo editing tools like GIMP, Photoshop, or online editors to blur sensitive areas. Consider screenshot alternatives that exclude PII.',
        icon: Info,
        color: 'text-blue-600 bg-blue-50 border-blue-200'
      });
    }

    return recommendations;
  };

  const recommendations = getRecommendations();

  return (
    <div className="space-y-4">
      <h4 className="font-semibold text-slate-800 text-lg">Security Recommendations</h4>
      
      <div className="space-y-3">
        {recommendations.map((rec, index) => {
          const IconComponent = rec.icon;
          return (
            <div key={index} className={`p-4 border rounded-lg ${rec.color}`}>
              <div className="flex items-start space-x-3">
                <IconComponent className="h-5 w-5 mt-0.5 flex-shrink-0" />
                <div>
                  <h5 className="font-medium mb-1">{rec.title}</h5>
                  <p className="text-sm opacity-90">{rec.description}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {file.riskScore >= 5 && (
        <div className="mt-6 p-4 bg-slate-50 border border-slate-200 rounded-lg">
          <h5 className="font-medium text-slate-800 mb-2">Recommended Tools:</h5>
          <ul className="text-sm text-slate-600 space-y-1">
            <li>• <strong>GIMP:</strong> Free image editor with blur and redaction tools</li>
            <li>• <strong>Canva:</strong> Online editor with privacy-focused templates</li>
            <li>• <strong>Paint/Preview:</strong> Built-in tools for quick edits</li>
            <li>• <strong>Photoshop:</strong> Professional editing with advanced privacy features</li>
          </ul>
        </div>
      )}
    </div>
  );
};
