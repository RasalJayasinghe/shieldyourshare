import React, { useRef, useState, useEffect } from 'react';
import { Upload, Image, Video, Loader2 } from 'lucide-react';
import { FileData, PIIDetection } from '@/types/file';
import { initializeAI, detectPII } from '@/services/aiDetection';
import { supabase } from '@/integrations/supabase/client';

interface FileUploadProps {
  onFileUpload: (files: FileData[]) => void;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFileUpload }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [aiInitialized, setAiInitialized] = useState(false);

  useEffect(() => {
    const setupAI = async () => {
      await initializeAI();
      setAiInitialized(true);
    };
    setupAI();
  }, []);

  const generateMockDetections = (): PIIDetection[] => {
    const mockDetections: PIIDetection[] = [];
    const detectionTypes: PIIDetection['type'][] = ['email', 'phone', 'name', 'address'];
    
    // Randomly generate 0-3 detections
    const numDetections = Math.floor(Math.random() * 4);
    
    for (let i = 0; i < numDetections; i++) {
      const type = detectionTypes[Math.floor(Math.random() * detectionTypes.length)];
      mockDetections.push({
        type,
        confidence: 0.75 + Math.random() * 0.25,
        location: {
          x: Math.random() * 300,
          y: Math.random() * 200,
          width: 100 + Math.random() * 100,
          height: 20 + Math.random() * 30
        },
        text: type === 'email' ? 'user@email.com' : 
              type === 'phone' ? '(555) 123-4567' :
              type === 'name' ? 'John Doe' : '123 Main St'
      });
    }
    
    return mockDetections;
  };

  const calculateRiskScore = (detections: PIIDetection[]): number => {
    if (detections.length === 0) return 0;
    
    const baseScore = detections.length * 2.5;
    const confidenceBonus = detections.reduce((sum, d) => sum + d.confidence, 0);
    
    return Math.min(10, Math.round(baseScore + confidenceBonus));
  };

  const processFiles = async (files: FileList) => {
    if (!aiInitialized) {
      console.warn('AI models not yet initialized');
      return;
    }

    setIsProcessing(true);
    const processedFiles: FileData[] = [];
    
    for (const file of Array.from(files)) {
      if (file.type.startsWith('image/') || file.type.startsWith('video/')) {
        const url = URL.createObjectURL(file);
        const fileId = Math.random().toString(36).substr(2, 9);
        
        // Create initial file entry with scanning status
        const initialFile: FileData = {
          id: fileId,
          name: file.name,
          type: file.type.startsWith('image/') ? 'image' : 'video',
          url,
          size: file.size,
          detections: [],
          riskScore: 0,
          status: 'scanning'
        };
        
        processedFiles.push(initialFile);
        
        // Store file in database
        await supabase.from('uploaded_files').insert({
          id: fileId,
          name: file.name,
          type: file.type.startsWith('image/') ? 'image' : 'video',
          url: url,
          size: file.size,
          status: 'scanning'
        });
      }
    }
    
    // Show files immediately with scanning status
    onFileUpload(processedFiles);
    
    // Process each file with AI
    for (let i = 0; i < processedFiles.length; i++) {
      const file = Array.from(files)[i];
      const fileData = processedFiles[i];
      
      try {
        const detections = await detectPII(file);
        const riskScore = calculateRiskScore(detections);
        
        // Update file with results
        fileData.detections = detections;
        fileData.riskScore = riskScore;
        fileData.status = 'complete';
        
        // Update database
        await supabase.from('uploaded_files').update({
          risk_score: riskScore,
          status: 'complete'
        }).eq('id', fileData.id);
        
        // Store detections in database
        for (const detection of detections) {
          await supabase.from('pii_detections').insert({
            file_id: fileData.id,
            type: detection.type,
            confidence: detection.confidence,
            location_x: detection.location.x,
            location_y: detection.location.y,
            location_width: detection.location.width,
            location_height: detection.location.height,
            text: detection.text
          });
        }
        
      } catch (error) {
        console.error('Error processing file:', error);
        fileData.status = 'error';
        await supabase.from('uploaded_files').update({
          status: 'error'
        }).eq('id', fileData.id);
        onFileUpload([...processedFiles]);
      }
    }
    
    // Final update to show all completed results
    onFileUpload([...processedFiles]);
    setIsProcessing(false);
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files) {
      await processFiles(e.dataTransfer.files);
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      await processFiles(e.target.files);
    }
  };

  return (
    <div className="w-full">
      <div
        onDrop={handleDrop}
        onDragOver={(e) => e.preventDefault()}
        onDragEnter={() => setIsDragging(true)}
        onDragLeave={() => setIsDragging(false)}
        className={`
          border-2 border-dashed rounded-xl p-12 text-center transition-all duration-200
          ${isDragging 
            ? 'border-blue-500 bg-blue-50' 
            : 'border-slate-300 hover:border-blue-400 hover:bg-slate-50'
          }
        `}
      >
        <div className="space-y-4">
          <div className="flex justify-center space-x-4">
            <div className="p-3 bg-blue-100 rounded-full">
              <Upload className="h-8 w-8 text-blue-600" />
            </div>
            <div className="p-3 bg-green-100 rounded-full">
              <Image className="h-8 w-8 text-green-600" />
            </div>
            <div className="p-3 bg-purple-100 rounded-full">
              <Video className="h-8 w-8 text-purple-600" />
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold text-slate-800 mb-2">
              Upload Images or Videos
            </h3>
            <p className="text-slate-600 mb-4">
              Drag and drop your files here, or click to browse
            </p>
            <div className="flex justify-center">
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={!aiInitialized || isProcessing}
                className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 text-white px-6 py-3 rounded-lg font-medium transition-colors duration-200 flex items-center gap-2"
              >
              {!aiInitialized ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Initializing AI...
                </>
              ) : isProcessing ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                'Choose Files'
              )}
            </button>
            </div>
          </div>
          
          <p className="text-sm text-slate-500">
            Supports JPG, PNG, GIF, MP4, MOV, AVI up to 100MB
          </p>
        </div>
      </div>
      
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/*,video/*"
        onChange={handleFileSelect}
        className="hidden"
      />
    </div>
  );
};
