-- Create uploaded_files table
CREATE TABLE public.uploaded_files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('image', 'video')),
  url TEXT NOT NULL,
  size BIGINT NOT NULL,
  risk_score INTEGER NOT NULL DEFAULT 0 CHECK (risk_score >= 0 AND risk_score <= 10),
  status TEXT NOT NULL DEFAULT 'scanning' CHECK (status IN ('scanning', 'complete', 'error')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create pii_detections table
CREATE TABLE public.pii_detections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id UUID NOT NULL REFERENCES public.uploaded_files(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('email', 'phone', 'ssn', 'credit_card', 'name', 'address', 'license_plate')),
  confidence DECIMAL(3,2) NOT NULL CHECK (confidence >= 0 AND confidence <= 1),
  location_x INTEGER NOT NULL,
  location_y INTEGER NOT NULL,
  location_width INTEGER NOT NULL,
  location_height INTEGER NOT NULL,
  text TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.uploaded_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pii_detections ENABLE ROW LEVEL SECURITY;

-- Create policies for public access
CREATE POLICY "Allow public read access to uploaded_files" 
ON public.uploaded_files FOR SELECT 
USING (true);

CREATE POLICY "Allow public insert to uploaded_files" 
ON public.uploaded_files FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow public update to uploaded_files" 
ON public.uploaded_files FOR UPDATE 
USING (true);

CREATE POLICY "Allow public delete from uploaded_files" 
ON public.uploaded_files FOR DELETE 
USING (true);

CREATE POLICY "Allow public read access to pii_detections" 
ON public.pii_detections FOR SELECT 
USING (true);

CREATE POLICY "Allow public insert to pii_detections" 
ON public.pii_detections FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Allow public update to pii_detections" 
ON public.pii_detections FOR UPDATE 
USING (true);

CREATE POLICY "Allow public delete from pii_detections" 
ON public.pii_detections FOR DELETE 
USING (true);

-- Create function for updating timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_uploaded_files_updated_at
  BEFORE UPDATE ON public.uploaded_files
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at();

-- Create indexes for better performance
CREATE INDEX idx_uploaded_files_status ON public.uploaded_files(status);
CREATE INDEX idx_uploaded_files_created_at ON public.uploaded_files(created_at);
CREATE INDEX idx_pii_detections_file_id ON public.pii_detections(file_id);
CREATE INDEX idx_pii_detections_type ON public.pii_detections(type);